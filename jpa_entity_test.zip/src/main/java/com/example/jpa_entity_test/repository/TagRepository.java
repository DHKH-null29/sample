package com.example.jpa_entity_test.repository;

import com.example.jpa_entity_test.entity.Tag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TagRepository extends JpaRepository<Tag, Long> {
    @Query("select t from Tag t join fetch t.member")
    List<Tag> findAllIncludesTag();

}