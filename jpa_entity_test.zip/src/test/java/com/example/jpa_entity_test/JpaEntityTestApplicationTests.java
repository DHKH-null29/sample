package com.example.jpa_entity_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaEntityTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
