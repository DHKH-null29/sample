package com.wnis.milkyway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MilkywayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MilkywayApplication.class, args);
	}

}
